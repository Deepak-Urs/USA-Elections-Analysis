const express = require('express')
const mongodb = require('mongodb')
const {MongoClient, ObjectID} = require("mongodb")
const { modelNames } = require('mongoose')

const connectionURL = 'mongodb://127.0.0.1:27017'
const databaseName = 'twitter_data'

const app = express()
const port = 3000
let db 
let data

const loadDB = async () => {
    await MongoClient.connect(connectionURL, { useNewUrlParser: true}, (error, client) => {
    if(error) {
        return console.log('Unable to connect to database')
    }
    console.log("connected correctly!")
    db = client.db(databaseName)
    data = db.collection('data')
})
}

loadDB()

app.get('/data', async (req, res) => {
    try{ 
        var aggCursor = data.aggregate([
            {   
                $match:
                {
                    Datetime:{
                        $gt: new Date("2022-11-01"),
                        $lt: new Date("2022-11-09")
                    },
                    sentiment:/^(Positive|Negative)$/
                }
            },
            {
                $group:
                {
                    _id: { State_Code: "$State_Code", sentiments:"$sentiment", party:"$party"},
                    sentiments: { $sum: 1 },
                }
            }
        ])
        result = []
        await aggCursor.forEach(doc => result.push(doc))
        res.send(result)
    }
    catch(e){
        console.log(e)
        res.status(500).send()
    }
})
app.listen(port, () => {
    console.log('Server is up on port' + port)
})
