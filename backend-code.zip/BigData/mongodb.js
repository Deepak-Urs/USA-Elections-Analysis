const mongodb = require('mongodb')
const {MongoClient, ObjectID} = require("mongodb")
const { modelNames } = require('mongoose')

const connectionURL = 'mongodb://127.0.0.1:27017'
const databaseName = 'tweets'
let db

const loadDB = async () => {
        await MongoClient.connect(connectionURL, { useNewUrlParser: true}, (error, client) => {
        if(error) {
            return console.log('Unable to connect to database')
        }
        console.log("connected correctly!")
        db = client.db(databaseName)
        return db
    })
}

module.exports = loadDB;